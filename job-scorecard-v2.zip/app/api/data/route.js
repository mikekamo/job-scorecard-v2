import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'

const DATA_FILE = path.join(process.cwd(), 'data', 'jobs.json')

// Ensure data directory exists
function ensureDataDirectory() {
  const dataDir = path.dirname(DATA_FILE)
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true })
  }
}

// GET - Load jobs from file
export async function GET() {
  try {
    ensureDataDirectory()
    
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf8')
      const jobs = JSON.parse(data)
      return NextResponse.json(jobs)
    } else {
      // Return empty array if no file exists yet
      return NextResponse.json([])
    }
  } catch (error) {
    console.error('Error loading jobs:', error)
    return NextResponse.json({ error: 'Failed to load jobs' }, { status: 500 })
  }
}

// POST - Save jobs to file
export async function POST(request) {
  try {
    const jobs = await request.json()
    
    ensureDataDirectory()
    
    // Save to file with pretty formatting
    fs.writeFileSync(DATA_FILE, JSON.stringify(jobs, null, 2))
    
    console.log(`💾 Saved ${jobs.length} jobs to file`)
    return NextResponse.json({ success: true, count: jobs.length })
  } catch (error) {
    console.error('Error saving jobs:', error)
    return NextResponse.json({ error: 'Failed to save jobs' }, { status: 500 })
  }
} 